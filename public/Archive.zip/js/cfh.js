$(document).ready(function(){
  $('.scrollspy').scrollSpy();
});